package com.example.Tarea1.Controllers;

import com.example.Tarea1.Model.User;
import com.example.Tarea1.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<User> list() {return userService.listUsers(); }

    @PutMapping("/{userId}/{matchId}")
    public ResponseEntity<User> addMatchToUser(@PathVariable Long userId, @PathVariable Long matchId) {
        userService.addMatchToUser(userId, matchId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
