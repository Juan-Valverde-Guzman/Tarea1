package com.example.Tarea1.Service;

import com.example.Tarea1.Model.User;
import com.example.Tarea1.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> listUsers() { return userRepository.findAll(); }

    public void addMatchToUser(Long userId, Long matchId) {
        User user = userRepository.findById(userId).orElse(null);
        User matchUser = userRepository.findById(matchId).orElse(null);

        if (user != null && matchUser != null) {
            user.getUsersMatch().add(matchUser);
            userRepository.save(user);
        } else {
            throw new IllegalArgumentException("Usuario o usuario relacionado no encontrado");
        }
    }
}
