export interface User {

    id:0,

    name:'',

    pass:'',

    usersMatch: [
        {id:0}
    ]

}