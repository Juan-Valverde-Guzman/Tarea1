import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { User } from '../model/User';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  form:FormGroup

  constructor(private formBuilder:FormBuilder, private userService:UserService, private router: Router) {

    this.form = this.formBuilder.group({

      "name": '',

      "pass": ''

    })

  }

 login() {

  const nombre = this.form.get('name')?.value

  const contraseña = this.form.get('pass')?.value

  this.userService.getUsers().subscribe({

    next: (users) => {

      const user = users.find(u => u.name === nombre && u.pass === contraseña)

      if (user) {

        this.router.navigate(['/home', user.id])

      }

    },

    error: err => console.log(err)

  })

 }

}