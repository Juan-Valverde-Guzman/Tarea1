import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

 users = [
    {id:0, name:'', pass:'', usersMatch: [
      {id:0}
    ]}
  ]

  userId: number | undefined

constructor(private userService:UserService, private formBuilder:FormBuilder, private route: ActivatedRoute) {

  this.getAllUsers()

  this.getId()

}

match(id: number) {

  this.users

}

getId() {

  this.route.params.subscribe(params => {

    this.userId = +params['id']

    console.log("Aqui esta el id ", this.userId)

  })

}

getAllUsers() {

  this.userService.getUsers().subscribe({

    next: res => {

      console.log(res)

      this.users = res

    },

    error: err => console.log(err)

  })

}

}
